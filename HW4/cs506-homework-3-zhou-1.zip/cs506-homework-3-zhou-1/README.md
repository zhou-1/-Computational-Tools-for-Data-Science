Deatiled explain is in HW3_SocialNetworksandRecommendationSystems_ZhouShen.pdf file.    
