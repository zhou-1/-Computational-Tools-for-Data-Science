'''
old_edges.txt: every line contains the names of 2 researchers that have co-authorized a paper 
in one of the top ML CONFEREnCES BETWEEN 2010 AND 2016
new_edges.txt: every line contains the name of 2 researchers (from old edges file) that formed
a new collaboration in either 2017 or 2018
'''
# NetworkX is a Python library for studying graphs and networks
import networkx as nx 
import math

#a
def create_graph_with_old_edges():
	G = nx.Graph()
	f = open("old_edges.txt", 'r', encoding="utf-8")
	iter_f = iter(f)
	for line in iter_f:
		line = line.replace("\n", "").split("\t")
		G.add_edge(line[0], line[1])
	return G

#b
def keep_track_of_new_edges():
    G = nx.Graph()
    f = open("new_edges.txt", 'r', encoding='utf-8')
    iter_f = iter(f)
    for line in iter_f:
        line = line.replace("\n", "").split("\t")
        G.add_edge([0], line[1])
    node_list = list(G.nodes)
    author_list = []
    for x in node_list:
			  # pick that formedat least 10 new connections
        if G.degree[x] >= 10:
            author_list.append(x)
    return G, author_list

#c
def common_friends_number(G, X):
    non_friend_list = []
    common_number_list = []
    # create neighbor list and set for X
    neighbour_list = list(G.neighbors(X))
    set1 = set(neighbour_list)
    # neighbour of X
    for neighbour in neighbour_list:
        # neighbour of X's neighbour
        neighbour_neighbour_list = list(G.neighbors(neighbour))
        for neighbour_neighbour in neighbour_neighbour_list:
            if neighbour_neighbour not in non_friend_list and neighbour_neighbour not in neighbour_list and neighbour_neighbour != X:
                non_friend_list.append(neighbour_neighbour)
                neighbour_neighbour_neighbour_list = list(G.neighbors(neighbour_neighbour))
                set2 = set(neighbour_neighbour_neighbour_list)
                common_friend_list = list(set1.intersection(set2))
                common_number_list.append(len(common_friend_list))
    # 2 sets
    non_friend_dict = dict(zip(non_friend_list, common_number_list))
    list_y = sorted(non_friend_dict.items(), key=lambda item:item[1], reverse=True)
    return list_y

#d
def jaccard_index(G, X):
    jaccard_index_score = []
    # neighbor list and set of X
    X_neighbour_list = list(G.neighbors(X))
    set_X_neighbour = set(X_neighbour_list)
    # extract name from list_y
    list_y = dict(common_friends_number(G, X))
    list_y_name = []
    for name in list_y.keys():
        list_y_name.append(name)
    # iterate in list_y
    for name in list_y_name:
        set_y_neighbour = set(list(G.neighbors(name)))
        # intersect size
        intersect_size = len(list(set_y_neighbour.intersection(set_X_neighbour)))
        # union size
        union_size = len(list(set_y_neighbour.union(set_X_neighbour)))
        # calculate score
        jaccard_index_score.append(intersect_size / union_size)
    # sort
    jaccard_index_dict = sorted(dict(zip(list_y_name, jaccard_index_score)).items(), key=lambda item:item[1], reverse=True)
    return jaccard_index_dict

#e
def adamic_adar_index(G, X):
    adamic_adar_index_score = []
    # neighbor list and set of X 
    X_neighbour_list = list(G.neighbors(X))
    set_X_neighbour = set(X_neighbour_list)
    # extract name from list_y
    list_y = dict(common_friends_number(G, X))
    list_y_name = []
    for name in list_y.keys():
        list_y_name.append(name)
    # iterate in list_y
    for name in list_y_name:
        set_y_neighbour = set(list(G.neighbors(name)))
        # intersect
        intersection_list = list(set_y_neighbour.intersection(set_X_neighbour))
        score = 0
        for node in intersection_list:
            score += (1 / (math.log(len(list(G.neighbors(node))))))
        adamic_adar_index_score.append(score)
    # sort
    adamic_adar_index_dict = sorted(dict(zip(list_y_name, adamic_adar_index_score)).items(), key=lambda item: item[1], reverse=True)
    return adamic_adar_index_dict

#f
def extract_name_from_dict(dictionary):
	# get dictionary
    list_y = dict(dictionary)
    list_y_name = []
    for name in list_y.keys():
        list_y_name.append(name)
    return list_y_name
##average among 10 first of users X
def average_predict_new_formed(new_G, author_list, old_G):
    sum_common_friend_number = 0
    sum_jaccard_index = 0
    sum_adamic_adar_index = 0
    # iterate author list
    for author in author_list:
        new_neighbour_list = new_G.neighbors(author)
        set_new_neighbour_list = set(list(new_neighbour_list))
        # common friend number
        set_common_friend_number = set(list(extract_name_from_dict(common_friends_number(old_G, author)))[:10])
        sum_common_friend_number += len(list(set_common_friend_number.intersection(set_new_neighbour_list)))
        # jaccard index
        set_jaccard_index = set(list(extract_name_from_dict(jaccard_index(old_G, author)))[:10])
        sum_jaccard_index += len(list(set_jaccard_index.intersection(set_new_neighbour_list)))
        # adamic adar index
        set_adamic_adar_index = set(list(extract_name_from_dict(adamic_adar_index(old_G, author)))[:10])
        sum_adamic_adar_index += len(list(set_adamic_adar_index.intersection(set_new_neighbour_list)))
    # print out
    print("common friend number: ", sum_common_friend_number / len(author_list))
    print("jaccard index: ", sum_jaccard_index / len(author_list))
    print("adamic adar index: ", sum_adamic_adar_index / len(author_list))
##average among newly formed edges
def rank_of_new_formed(new_G, author_list, old_G):
    rank_common_friend_number = []
    rank_jaccard_index = []
    rank_adamic_adar_index = []
    # iterate author list
    for author in author_list:
        new_neighbour_list = list(new_G.neighbors(author))
        sum_common_friend_number = 0
        sum_jaccard_index = 0
        sum_adamix_adar_index = 0
        # common friend number, jaccard index, adamic adar index
        list_common_friend_number = list(extract_name_from_dict(common_friends_number(old_G, author)))
        list_jaccard_index = list(extract_name_from_dict(jaccard_index(old_G, author)))
        list_adamic_adar_index = list(extract_name_from_dict(adamic_adar_index(old_G, author)))
        # iterate neighbor list
        for new_formed_collaboration in new_neighbour_list:
            if new_formed_collaboration in list_common_friend_number:
                sum_common_friend_number += (list_common_friend_number.index(new_formed_collaboration) + 1)
            if new_formed_collaboration in list_jaccard_index:
                sum_jaccard_index += (list_jaccard_index.index(new_formed_collaboration) + 1)
            if new_formed_collaboration in list_adamic_adar_index:
                sum_adamix_adar_index += (list_adamic_adar_index.index(new_formed_collaboration) + 1)
        # append average
        rank_common_friend_number.append(sum_common_friend_number / len(new_neighbour_list))
        rank_jaccard_index.append(sum_jaccard_index / len(new_neighbour_list))
        rank_adamic_adar_index.append(sum_adamix_adar_index / len(new_neighbour_list))
    # print out
    print("common friend number: ", sum(rank_common_friend_number) / len(rank_common_friend_number))
    print("jaccard index: ", sum(rank_jaccard_index) / len(rank_jaccard_index))
    print("adamic adar index: ", sum(rank_adamic_adar_index) / len(rank_adamic_adar_index))

if __name__ == "__main__":
	#create_graph_with_old_edges()
	#keep_track_of_new_edges()
	#old_G = create_old_edges_graph()
	#author_list, new_G = keep_track_of_new_edges()

	#average_predict_new_formed(new_G, author_list, old_G)
	#rank_of_new_formed(new_G, author_list, old_G)