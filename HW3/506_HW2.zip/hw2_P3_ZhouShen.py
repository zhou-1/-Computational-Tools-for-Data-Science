import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time

from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score


# read data
def read_file():
    mnist_data = np.load("mnist_data.npy")
    mnist_labels = np.load("mnist_labels.npy")
    #print(mnist_data.shape, mnist_labels.shape)
    data = pd.DataFrame(list(mnist_data))
    labels = pd.DataFrame(list(mnist_labels))
    return data, labels

# PCA get data
def PCA_data():
    data, labels = read_file()
    # create PCA model
    pca = PCA(n_components=784)
    # fit data into model
    pca.fit(data)
    # get explained variance
    i = 1
    evr = pca.explained_variance_ratio_
    while i < len(evr):
        evr[i] += evr[i - 1]
        if (evr[i] >= 1):
            evr[i] = 1
        i += 1
    # plot
    plt.subplot(111)
    plt.plot(range(1, 785), evr, 'r-', lw=5, alpha=0.6)
    plt.title("CDF of the explained variance")
    plt.show()

# choose a number of principal components to KNN
def PCA_chosenNumofPComp_KNN():
	data, labels = read_file()
	pca = PCA(n_components=300)
	data = pca.fit_transform(data)
	X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2)
	# choose k for KNN
	knn = KNeighborsClassifier(n_neighbors=1)
	result = knn.fit(X_train, y_train)
	scores = result.score(X_train, y_train)
	y_predict = knn.predict(X_test)
	scores_test = accuracy_score(y_test, y_predict)
	# print out accuracy
	print("The training accuracy is: ")
	print(scores)
	print("The testing accuracy is: ")
	print(scores_test)

# Sample a part of dataset and fixed k
def PCA_KNN_sample():
    data,labels = read_file()
    pca1 = PCA(n_components=784)
    data = pca1.fit_transform(data)
    # train set
    train_size = [3000, 6000, 9000, 12000, 15000, 18000, 21000]
    time_comp1 = []
    # get size
    size = []
    for i in range(1, 7):
        size.append(i / 7)
    size.append(0.9999999999)  # to prevent size is not less than 1
    for i in size:
        X_train, X_test, y_train, y_test = train_test_split(data, labels, train_size=i)
        knn = KNeighborsClassifier(n_neighbors=1)
        # training
        start = time.time()
        result = knn.fit(X_train, y_train)
        end = time.time()
        time_comp1.append(end - start)
        print(end - start)
    # plot
    plt.scatter(train_size, time_comp1, alpha=0.6, c='r', label='sample a part of dataset')
    plt.title("relationship between the size of the dataset sample and score")
    plt.show()


# Varying number of principal components and fixed k
def PCA_KNN_component():
    data,labels = read_file()
    comp = [50, 150, 250, 350, 450, 550, 650, 750]
    time_comp2 = []
    knn = KNeighborsClassifier(n_neighbors=1)
    for i in comp:
        pca2 = PCA(n_components=i)
        temp = pca2.fit_transform(data)
        X_train, X_test, y_train, y_test = train_test_split(temp, labels, test_size=0.2)
        start = time.time()
        result = knn.fit(X_train,y_train)
        end = time.time()
        time_comp2.append(end - start)
        print(end - start)
    # plot
    plt.scatter(comp, time_comp2, alpha=0.6, c='b', label='fixed K')
    plt.title("relationship between the size of the sample and score")
    plt.show()


# compare most accurate model and fatest model
def compare_fast_and_accurate():
    # fatest model
    data, labels = read_file()
    k = 1
    knn = KNeighborsClassifier(n_neighbors=k)
    component = 300
    pca = PCA(n_components=component)
    data = pca.fit_transform(data)
    X_train, X_test, y_train, y_test = train_test_split(data, labels, train_size=0.65)
    start = time.time()
    result = knn.fit(X_train, y_train)
    end = time.time()
    y_predict = knn.predict(X_test)
    scores_test = accuracy_score(y_test, y_predict)
    print("fast model time", end - start)
    print("fast model score", scores_test)
    # most accurate model
    data, labels = read_file()
    k = 1
    knn = KNeighborsClassifier(n_neighbors=k)
    component = 300
    pca = PCA(n_components=component)
    data = pca.fit_transform(data)
    X_train, X_test, y_train, y_test = train_test_split(data, labels, train_size=0.9999999999)
    start = time.time()
    result = knn.fit(X_train, y_train)
    end = time.time()
    y_predict = knn.predict(X_test)
    scores_test = accuracy_score(y_test, y_predict)
    print("most accurate model time", end - start)
    print("most accurate model score", scores_test)

# plot 10 first principal components
def plot_10_first_principal_components():
    data, labels = read_file()
    comp = [50, 60, 70, 80, 90, 100, 110, 120, 130, 140]
    time_comp2 = []
    train_size = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    knn = KNeighborsClassifier(n_neighbors=1)
    for i in comp:
        pca2 = PCA(n_components=i)
        temp = pca2.fit_transform(data)
        X_train, X_test, y_train, y_test = train_test_split(temp, labels, test_size=0.2)
        start = time.time()
        result = knn.fit(X_train, y_train)
        end = time.time()
        time_comp2.append(end - start)
        print(end - start)
    plt.scatter(train_size, time_comp2, alpha=0.6, c='b', label='fixed K')
    plt.show()



if __name__ == "__main__":
    #PCA_data()
    #PCA_chosenNumofPComp_KNN()
    #PCA_KNN_sample()
    #PCA_KNN_component()
    #compare_fast_and_accurate()\
    plot_10_first_principal_components()