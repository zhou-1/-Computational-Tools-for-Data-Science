import numpy as np
import pandas as pd

import matplotlib.pyplot as plt

## Q1. Least Squares and Logistic Regression


# generate data for points
def generate_data(ratio):
	# generate 3 subset for red, blue and  outliers points (total 50)
	# based on y = x; y = x + 1; y = x-1 
	red = []
	blue = []
	number = 50
	ratio = ratio
	# create random points
	points = np.random.uniform(low=[-4,-4], high=[4, 4], size=(1000,2))
	# put random points into  red, blue
	for x, y in points:
		if x+1<y and x+5>y and x>-4 and x<4 and y<4:
			red.append([x,y,0])
		elif x-1>y and x-5<y and x>-1 and x<4 and y<2 and y>-4.5:
			blue.append([x,y,1]) # has outlier
		else:
			continue
	outliers = np.random.uniform(low=[7, -7], high=[9, -5], size=(1000,2))
	samples =red[:int(number*ratio[0])] + blue[:int(number*ratio[1])] + [[x, y, 1] for x, y in list(outliers[:int(number*ratio[2])])]
	return samples


# Least Squares
def least_square(ratio):
	samples = np.array(generate_data(ratio))
	y = samples[:,-1].reshape(-1,1)
	x = samples[:, :-1]
	ones = np.ones(len(y)).astype(float).reshape(-1,1)
	x = np.concatenate((x, ones) , axis=1)
	w = np.random.rand(3).reshape(1,-1)
	# update w
	w = y.T @ x @ np.linalg.pinv(x.T @ y @y.T @x)
	# plot
	i = range(-4, 8 )
	f_x = -(w[0,0]*i+w[0,2])/w[0,1]
	function = [i, f_x]
	#plot(ratio, function)
	return function



# Logistic Regression
def logistic_regression(ratio):
	samples = np.array(generate_data(ratio))
	y = samples[:,-1].reshape(-1,1)
	x = samples[:, :-1]
	ones = np.ones(len(y)).astype(float).reshape(-1,1)
	x = np.concatenate((x, ones) , axis=1)
	w = np.random.rand(3).reshape(1,-1)
	for j in range(100):
		for i in range(len(y)):
			xi = x[i,:].reshape(1,-1)
			f_x = w @ xi.T 
			g_x = 1/(1+np.exp(f_x))
			w -= 0.01*(g_x-y[i])*xi
	# plot
	i = range(-4, 8 )
	f_x = -(w[0,0]*i+w[0,2])/w[0,1]
	function = [i, f_x]
	#plot(ratio, function)
	return function



# plot data
def plot(ratio, function):
	# last column is class label
	classes = {}
	samples = generate_data(ratio)
	for x, y, label in samples:
		if label not in classes:
			classes[label]=[[x], [y]]
		else:
			classes[label][0].append(x)
			classes[label][1].append(y)
	# PLOT
	color = ['red', 'blue']
	marker= ['x', 'o']
	for i, label in  enumerate(classes):
		plt.scatter(classes[label][0], classes[label][1], c= color[i], marker=marker[i])
	# check for least square or logistic regression
	if function:
		plt.plot(function[0], function[1])
	plt.xlim([-4,9])
	plt.ylim([-9, 4])
	#plt.show()


# fit data into graph
def fit_data():
	# plot 2 subsets of data
	ratio1 = [0.5, 0.5, 0]
	function_least_square = least_square(ratio1)
	function_logistic_regression = logistic_regression(ratio1)
	plot(ratio1, function_least_square)
	plot(ratio1, function_logistic_regression)
	plt.show()

	# plot 2 subsets of data with outliers
	ratio2 = [0.5, 0.5, 0.2]
	function_least_square2 = least_square(ratio2)
	function_logistic_regression2 = logistic_regression(ratio2)
	plot(ratio2, function_least_square2)
	plot(ratio2, function_logistic_regression2)
	plt.show()



if __name__ == "__main__":
    fit_data()

# plot 2 subsets of data
#plot([0.5, 0.5, 0], None)
#least_square([0.5, 0.5, 0])
#logistic_regression([0.5, 0.5, 0])

# plot 2 subsets of data with outliers
#plot([0.5, 0.5, 0.2], None)
#least_square([0.5, 0.5, 0.2])
