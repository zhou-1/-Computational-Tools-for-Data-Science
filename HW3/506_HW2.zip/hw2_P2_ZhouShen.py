import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier


# read 2 files
def read_file():
    mnist_data = np.load("mnist_data.npy")
    mnist_labels = np.load("mnist_labels.npy")
    #print(mnist_data.shape, mnist_labels.shape)

    data = pd.DataFrame(list(mnist_data))
    labels = pd.DataFrame(list(mnist_labels))
    return data, labels

# split dataset
def divide_dataset():
    data, labels = read_file()
    X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2)
    return X_train, X_test, y_train, y_test

# classify images using Logistic Regression
def logistic_regression():
    X_train, X_test, y_train, y_test = divide_dataset()
    # create logistic regression model
    LRModel = LogisticRegression()
    # trainning
    result = LRModel.fit(X_train,y_train)
    score_train=result.score(X_train,y_train)
    # testing
    score_test = LRModel.score(X_test, y_test)
    print("The training accuracy is ")
    print(score_train)
    print("The testing accuracy is ")
    print(score_test)

# classify dataset using KNN
def KNN():
    X_train, X_test, y_train, y_test = divide_dataset()
    scores_train = {}
    scores_test = {}
    for k in range(1, 26, 2):
        # create model for KNN with step 2
        knn = KNeighborsClassifier(n_neighbors=k)
        # training
        result = knn.fit(X_train,y_train)
        scores_train[k] = result.score(X_train, y_train)
        # testing
        y_pred = knn.predict(X_test)
        scores_test[k] = metrics.accuracy_score(y_test, y_pred)
    #print("the training accuracy of Logistic is ")
    #print(scores_train)
    #print("the testing accuracy of Logistic is ")
    #print(scores_test)
    plot(scores_train,scores_test)

# plot image
def plot(scores_train, scores_test):
	# train and test: key and val
    key_scores_train = scores_train.keys()
    val_scores_train = scores_train.values()
    key_scores_test = scores_test.keys()
    val_scores_test = scores_test.values()
    # get image
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.scatter(key_scores_train, val_scores_train, c = 'r', marker = "o", label = 'train')
    ax.scatter(key_scores_test, val_scores_test, c='b', marker="s", label='test')
    plt.legend(loc = 'upper left')
    plt.show()

# plot accuracy of model with different sizes of images with KNN
def KNN_different_size():
    data, labels = read_file()
    size = []
    # total is 21000, each subset has 3000 more items
    for i in range(1, 7):
        size.append(i / 7)
    size.append(0.9999999999)  # to prevent size is not less than 1
    # get different scores in train and test
    scores_train = {}
    scores_test = {}
    for i in size:
        X_train, X_test, y_train, y_test = train_test_split(data, labels, train_size=i)
        knn = KNeighborsClassifier(n_neighbors=1)
        # training
        result = knn.fit(X_train, y_train)
        scores_train[i] = result.score(X_train, y_train)
        # testing
        y_pred = knn.predict(X_test)
        scores_test[i] = metrics.accuracy_score(y_test, y_pred)
    # different train size
    train_size = [3000, 6000, 9000, 12000, 15000, 18000, 21000]
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.scatter(train_size, scores_test.values(), c='b', marker="s", label='test score')
    ax.scatter(train_size, scores_train.values(), c='r', marker="o", label='train score')
    plt.legend(loc='upper left')
    plt.title("relationship between the size of the sample and score")
    plt.show()


#if __name__ == "__main__":
#    KNN()